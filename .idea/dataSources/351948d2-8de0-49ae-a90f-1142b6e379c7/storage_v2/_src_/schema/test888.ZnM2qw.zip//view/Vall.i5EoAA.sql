create view Vall as (select
                       `s`.`sno`       AS `学号`,
                       `s`.`sname`     AS `sname`,
                       `s`.`ssex`      AS `ssex`,
                       `s`.`sbrithday` AS `sbrithday`,
                       `s`.`class`     AS `class`,
                       `ss`.`degree`   AS `degree`,
                       `c`.`cname`     AS `cname`,
                       `t`.`tno`       AS `tno`,
                       `t`.`tname`     AS `tname`,
                       `t`.`tsex`      AS `tsex`,
                       `t`.`tbirthday` AS `tbirthday`,
                       `t`.`prof`      AS `prof`,
                       `t`.`depart`    AS `depart`
                     from (((`test888`.`student` `s`
                       join `test888`.`score` `ss` on ((`s`.`sno` = `ss`.`sno`))) join `test888`.`course` `c`
                         on ((`c`.`cno` = `ss`.`cno`))) join `test888`.`teacher` `t` on ((`t`.`tno` = `c`.`tno`))));

